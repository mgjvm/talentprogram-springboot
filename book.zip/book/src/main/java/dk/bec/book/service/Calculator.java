package dk.bec.book.service;

public class Calculator {

    public int calculate() {
        return 10;
    }
}
