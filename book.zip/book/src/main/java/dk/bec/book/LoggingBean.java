package dk.bec.book;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class LoggingBean {

    private Logger logger = LoggerFactory.getLogger(LoggingBean.class);

    @Value("${my-custom-key}")
    private String myCustomKey;

    public void logSth() {
        System.out.println("Hi! We are in LoggingBean, value from properties.file=" + myCustomKey);
        logger.trace("A TRACE message");
        logger.debug("A DEBUG message");
        logger.info("A INFO message");
        logger.warn("A WARN message");
        logger.error("A ERROR message");
    }
}
