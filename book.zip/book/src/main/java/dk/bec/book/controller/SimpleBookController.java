package dk.bec.book.controller;

import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/simple-books")
public class SimpleBookController {

    @GetMapping
    public Iterable<SimpleBookDto> getAllBooks(HttpServletRequest httpServletRequest) {
        SimpleBookDto simpleBookDto1 = createSimpleBook(1, "Henryk Sienkiewicz", "W pustyni i w puszczy");
        SimpleBookDto simpleBookDto2 = createSimpleBook(2, "Adam Mickiewicz", "Pan Tadeusz");
        return Arrays.asList(simpleBookDto1, simpleBookDto2);
    }

    public static class SimpleBookDto {

        private long id;

        private String title;

        private String author;

        public long getId() {
            return id;
        }

        public void setId(long id) {
            this.id = id;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getAuthor() {
            return author;
        }

        public void setAuthor(String author) {
            this.author = author;
        }
    }

    private SimpleBookDto createSimpleBook(int id, String author, String title) {
        SimpleBookDto simpleBookDto1 = new SimpleBookDto();
        simpleBookDto1.setId(id);
        simpleBookDto1.setAuthor(author);
        simpleBookDto1.setTitle(title);
        return simpleBookDto1;
    }
}
