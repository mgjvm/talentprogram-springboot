package dk.bec.book.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class CalculatorTest {

    @Test
    public void shouldCalculate() {
        // given
        Calculator calculator = new Calculator();
        // when
        int sth = calculator.calculate();
        // then
        assertEquals(10, sth);
    }
}