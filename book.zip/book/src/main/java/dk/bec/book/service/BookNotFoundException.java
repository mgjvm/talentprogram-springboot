package dk.bec.book.service;

public class BookNotFoundException extends RuntimeException {
}
