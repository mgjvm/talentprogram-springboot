package dk.bec.book;

import java.util.Random;
import java.util.UUID;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import dk.bec.book.persistance.Book;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc
public class BookIntegrationTest {

    @Autowired
    private MockMvc mvc;

    @Test
    public void shouldCreateBookWithPostEndpoint() throws Exception {
        // given
        long id = new Random().nextLong();
        String author = "bookAuthor" + UUID.randomUUID().toString();
        String title = "bookTitle" + UUID.randomUUID().toString();
        Book book = createBook(id, author, title);
        // when
        mvc.perform(MockMvcRequestBuilders.post("/api/books")
            .content(serializeToJson(book))
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON))
            // then
            .andExpect(MockMvcResultMatchers.status().isCreated())
            .andExpect(MockMvcResultMatchers.jsonPath("$.id").exists());
        mvc.perform(MockMvcRequestBuilders.get("/api/books")
            .accept(MediaType.APPLICATION_JSON))
            .andExpect(MockMvcResultMatchers.status().isOk())
            .andExpect(MockMvcResultMatchers.jsonPath("$[0].title").value(title));
    }

    private String serializeToJson(Book book) {
        try {
            return new ObjectMapper().writeValueAsString(book);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    private Book createBook(long id, String author, String title) {
        Book book = new Book();
        book.setId(id);
        book.setAuthor(author);
        book.setTitle(title);
        return book;
    }
}
