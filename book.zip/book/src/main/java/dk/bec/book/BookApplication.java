package dk.bec.book;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookApplication {

    @Autowired
    private LoggingBean loggingBean;

    public static void main(String[] args) {
        SpringApplication.run(BookApplication.class, args);
    }

    @PostConstruct
    public void onInit() {
        loggingBean.logSth();
    }
}
